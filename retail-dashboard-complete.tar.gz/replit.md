# Overview

This is a retail dashboard application built for store managers to monitor inventory, expiration dates, waste analysis, and environmental conditions. The application features a React frontend with TypeScript, an Express.js backend, and uses Drizzle ORM with PostgreSQL for data persistence. It includes a chatbot interface for interactive assistance and comprehensive inventory management capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Framework**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for client-side routing
- **Charts**: Recharts for data visualization

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Management**: PostgreSQL-based sessions with connect-pg-simple
- **API Design**: RESTful API with JSON responses

## Key Components

### Database Schema
- **Users Table**: Basic user authentication with username/password
- **Products Table**: Comprehensive product information including:
  - Product details (name, category, supplier)
  - Inventory data (stock quantity, reorder levels)
  - Expiration tracking (dates, spoilage risk)
  - Sales metrics (volume, turnover rate)
- **Temperature Readings Table**: Environmental monitoring data for different storage locations

### Core Features
1. **Inventory Management**: Track products, stock levels, and reorder points
2. **Expiration Monitoring**: Alert system for products approaching expiration
3. **Waste Analysis**: Historical data on product spoilage and waste patterns
4. **Temperature Monitoring**: Real-time environmental condition tracking
5. **Interactive Chatbot**: AI-powered assistant for inventory queries
6. **Data Visualization**: Charts and graphs for business insights

### UI Components
- **Responsive Dashboard**: Mobile-first design with sidebar navigation
- **Metrics Cards**: Key performance indicators display
- **Data Tables**: Sortable and filterable product listings
- **Charts**: Pie charts for category distribution, line charts for trends
- **Chatbot Interface**: Fixed position chat window with conversation history

## Data Flow

1. **Data Collection**: Products and temperature readings are stored in PostgreSQL
2. **API Layer**: Express.js serves RESTful endpoints for CRUD operations
3. **Frontend Queries**: React Query manages API calls and caching
4. **Real-time Updates**: Dashboard refreshes data periodically
5. **User Interactions**: Filters, sorting, and chatbot queries trigger API calls

## External Dependencies

### Core Libraries
- **@neondatabase/serverless**: PostgreSQL database connectivity
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management
- **recharts**: Data visualization
- **@radix-ui/***: Accessible UI primitives
- **tailwindcss**: Utility-first CSS framework

### Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Static type checking
- **ESLint**: Code linting and formatting
- **PostCSS**: CSS processing

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite compiles React app to static files
2. **Backend Build**: ESBuild bundles Node.js application
3. **Database Setup**: Drizzle generates and runs migrations
4. **Static Assets**: Frontend built to `dist/public` directory

### Production Configuration
- **Environment Variables**: `DATABASE_URL` for PostgreSQL connection
- **Session Storage**: PostgreSQL-based session management
- **Static Serving**: Express serves built React application
- **Error Handling**: Centralized error middleware

### Key Architectural Decisions

1. **Monorepo Structure**: Frontend, backend, and shared code in single repository
2. **TypeScript Throughout**: Type safety across all layers
3. **Serverless Database**: Neon Database for scalable PostgreSQL
4. **Component-Based UI**: Modular React components with shadcn/ui
5. **API-First Design**: Clean separation between frontend and backend
6. **Real-time Monitoring**: Temperature and inventory tracking capabilities

The application is designed to be easily deployable on platforms like Replit, with development tools configured for rapid iteration and testing.