import { Card, CardContent } from "@/components/ui/card";
import { Box, AlertTriangle, RotateCcw, Thermometer } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface MetricsCardsProps {
  stats?: {
    totalProducts: number;
    highRiskItems: number;
    avgTurnoverRate: number;
    temperatureAlerts: number;
  };
  isLoading: boolean;
}

export function MetricsCards({ stats, isLoading }: MetricsCardsProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <Skeleton className="h-4 w-20 mb-2" />
              <Skeleton className="h-8 w-16 mb-2" />
              <Skeleton className="h-4 w-4 float-right" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const metrics = [
    {
      label: "Total Products",
      value: stats?.totalProducts || 0,
      icon: Box,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
    },
    {
      label: "High Risk Items",
      value: stats?.highRiskItems || 0,
      icon: AlertTriangle,
      color: "text-red-600",
      bgColor: "bg-red-50",
    },
    {
      label: "Avg Turnover Rate",
      value: `${stats?.avgTurnoverRate || 0}%`,
      icon: RotateCcw,
      color: "text-green-600",
      bgColor: "bg-green-50",
    },
    {
      label: "Temperature Alerts",
      value: stats?.temperatureAlerts || 0,
      icon: Thermometer,
      color: "text-yellow-600",
      bgColor: "bg-yellow-50",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      {metrics.map((metric) => (
        <Card key={metric.label} className="hover:shadow-lg transition-shadow duration-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 uppercase tracking-wide">
                  {metric.label}
                </p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {metric.value}
                </p>
              </div>
              <div className={`p-3 rounded-full ${metric.bgColor}`}>
                <metric.icon className={`w-6 h-6 ${metric.color}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
