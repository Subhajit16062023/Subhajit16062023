import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageCircle, X, Send } from "lucide-react";
import { cn } from "@/lib/utils";

interface Message {
  id: string;
  text: string;
  sender: "user" | "bot";
  timestamp: Date;
}

export function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hello! I'm your store assistant. How can I help you manage your inventory today?",
      sender: "bot",
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState("");

  const getBotResponse = (message: string): string => {
    const responses = {
      inventory: "I can help you check current inventory levels. Based on your data, you have several products with varying stock levels. Would you like me to highlight items that need reordering?",
      expiration: "I can see several items with upcoming expiration dates. Your Bell Pepper expires on 1/31/2025, and you have multiple products that may need immediate attention. Would you like a detailed expiration report?",
      temperature: "Temperature monitoring shows your Cold Storage is at 4.2°C (Normal), Frozen Storage at -18.5°C (Normal), and Dry Storage at 22.1°C with an Alert status due to humidity levels.",
      waste: "Historical waste data shows that Fruits & Vegetables category has the highest risk products. I recommend reviewing expiration dates and adjusting order quantities for perishable items.",
      risk: "You currently have 9 high-risk items in your inventory. These include Bell Pepper, Vegetable Oil, Parmesan Cheese, and others. Would you like me to provide specific recommendations for each?",
      help: "I can assist with inventory management, expiration monitoring, temperature alerts, waste analysis, and product recommendations. What specific area would you like help with?",
    };

    const messageWords = message.toLowerCase();
    for (const [key, response] of Object.entries(responses)) {
      if (messageWords.includes(key)) {
        return response;
      }
    }

    return "I can help you with inventory management, expiration monitoring, temperature alerts, and waste analysis. Please ask me about any of these topics, or type 'help' for more information!";
  };

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      sender: "user",
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");

    // Simulate bot response
    setTimeout(() => {
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: getBotResponse(inputValue),
        sender: "bot",
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, botMessage]);
    }, 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSendMessage();
    }
  };

  return (
    <div className="fixed bottom-5 right-5 z-50">
      {/* Chat Window */}
      {isOpen && (
        <Card className="w-80 h-96 mb-4 shadow-xl">
          <CardHeader className="bg-blue-600 text-white rounded-t-lg">
            <CardTitle className="flex items-center justify-between text-lg">
              <div className="flex items-center gap-2">
                <MessageCircle className="w-5 h-5" />
                Store Assistant
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setIsOpen(false)}
                className="text-white hover:bg-blue-700"
              >
                <X className="w-4 h-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0 flex flex-col h-80">
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={cn(
                      "max-w-[80%] p-3 rounded-lg",
                      message.sender === "user"
                        ? "bg-blue-600 text-white ml-auto"
                        : "bg-gray-100 text-gray-900"
                    )}
                  >
                    <p className="text-sm">{message.text}</p>
                  </div>
                ))}
              </div>
            </ScrollArea>
            <div className="p-4 border-t">
              <div className="flex gap-2">
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Type your message..."
                  className="flex-1"
                />
                <Button onClick={handleSendMessage}>
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Toggle Button */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 rounded-full bg-blue-600 hover:bg-blue-700 shadow-lg"
      >
        <MessageCircle className="w-6 h-6" />
      </Button>
    </div>
  );
}
