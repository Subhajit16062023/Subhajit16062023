import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Thermometer } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import type { TemperatureReading } from "@shared/schema";

export function TemperatureMonitor() {
  const { data: readings = [], isLoading } = useQuery<TemperatureReading[]>({
    queryKey: ["/api/temperature/latest"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6 text-center">
              <Skeleton className="h-6 w-32 mx-auto mb-4" />
              <Skeleton className="h-12 w-24 mx-auto mb-2" />
              <Skeleton className="h-4 w-20 mx-auto mb-4" />
              <Skeleton className="h-6 w-16 mx-auto" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
      {readings.map((reading) => (
        <Card key={reading.id} className="bg-gradient-to-br from-blue-500 to-purple-600 text-white">
          <CardContent className="p-6 text-center">
            <div className="flex items-center justify-center mb-4">
              <Thermometer className="w-5 h-5 mr-2" />
              <h3 className="text-lg font-semibold">{reading.location}</h3>
            </div>
            <div className="text-4xl font-bold mb-2">
              {reading.temperature}°C
            </div>
            <div className="text-sm opacity-90 mb-4">
              Humidity: {reading.humidity}%
            </div>
            <Badge 
              variant={reading.status === "Normal" ? "default" : "destructive"}
              className={reading.status === "Normal" ? "bg-green-500" : "bg-yellow-500"}
            >
              {reading.status}
            </Badge>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
