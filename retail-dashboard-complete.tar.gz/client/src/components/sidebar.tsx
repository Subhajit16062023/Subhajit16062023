import { Store, BarChart3, Package, Clock, Trash2, Thermometer, FileText } from "lucide-react";
import { cn } from "@/lib/utils";

const navigation = [
  { name: "Dashboard", href: "/dashboard", icon: BarChart3, current: true },
  { name: "Inventory", href: "/inventory", icon: Package, current: false },
  { name: "Expiration Monitor", href: "/expiration", icon: Clock, current: false },
  { name: "Waste Analysis", href: "/waste", icon: Trash2, current: false },
  { name: "Temperature", href: "/temperature", icon: Thermometer, current: false },
  { name: "Reports", href: "/reports", icon: FileText, current: false },
];

export function Sidebar() {
  return (
    <div className="fixed inset-y-0 left-0 z-50 w-64 bg-gradient-to-br from-blue-600 to-purple-700 transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0">
      <div className="flex items-center justify-center p-6">
        <div className="flex items-center text-white">
          <Store className="w-8 h-8 mr-3" />
          <h1 className="text-xl font-bold">RetailManager</h1>
        </div>
      </div>
      
      <nav className="mt-8 px-4">
        <ul className="space-y-2">
          {navigation.map((item) => (
            <li key={item.name}>
              <a
                href={item.href}
                className={cn(
                  "flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200",
                  item.current
                    ? "bg-white bg-opacity-20 text-white transform translate-x-1"
                    : "text-blue-100 hover:bg-white hover:bg-opacity-10 hover:text-white hover:transform hover:translate-x-1"
                )}
              >
                <item.icon className="w-5 h-5 mr-3" />
                {item.name}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
}
