import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Eye, Plus, AlertTriangle, Clock } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import type { Product } from "@shared/schema";

interface ProductTableProps {
  products: Product[];
  isLoading: boolean;
}

export function ProductTable({ products, isLoading }: ProductTableProps) {
  const getStatusBadge = (status: string) => {
    const variants = {
      Active: "bg-green-100 text-green-800",
      Discontinued: "bg-red-100 text-red-800",
      Backordered: "bg-yellow-100 text-yellow-800",
    };
    return variants[status as keyof typeof variants] || variants.Active;
  };

  const getRiskBadge = (risk: string) => {
    const variants = {
      High: "bg-red-100 text-red-800",
      Medium: "bg-yellow-100 text-yellow-800",
      Low: "bg-green-100 text-green-800",
    };
    return variants[risk as keyof typeof variants] || variants.High;
  };

  const getExpirationWarning = (expirationDate: string) => {
    const expDate = new Date(expirationDate);
    const today = new Date();
    const diffTime = expDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays <= 7) {
      return (
        <div className="text-red-600 text-sm flex items-center gap-1">
          <AlertTriangle className="w-3 h-3" />
          Expires soon
        </div>
      );
    } else if (diffDays <= 30) {
      return (
        <div className="text-yellow-600 text-sm flex items-center gap-1">
          <Clock className="w-3 h-3" />
          Expires in {diffDays} days
        </div>
      );
    }
    return null;
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Product Inventory</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4">
                <Skeleton className="h-12 w-12 rounded" />
                <div className="space-y-2">
                  <Skeleton className="h-4 w-[200px]" />
                  <Skeleton className="h-4 w-[100px]" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Product Inventory</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 font-semibold">Product</th>
                <th className="text-left py-3 px-4 font-semibold">Category</th>
                <th className="text-left py-3 px-4 font-semibold">Status</th>
                <th className="text-left py-3 px-4 font-semibold">Expiration</th>
                <th className="text-left py-3 px-4 font-semibold">Stock</th>
                <th className="text-left py-3 px-4 font-semibold">Turnover Rate</th>
                <th className="text-left py-3 px-4 font-semibold">Spoilage Risk</th>
                <th className="text-left py-3 px-4 font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product) => (
                <tr key={product.id} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-4">
                    <div>
                      <div className="font-medium">{product.productName}</div>
                      <div className="text-sm text-gray-500">{product.productId}</div>
                    </div>
                  </td>
                  <td className="py-3 px-4">{product.category}</td>
                  <td className="py-3 px-4">
                    <Badge className={getStatusBadge(product.status)}>
                      {product.status}
                    </Badge>
                  </td>
                  <td className="py-3 px-4">
                    <div>{product.expirationDate}</div>
                    {getExpirationWarning(product.expirationDate)}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-medium">{product.stockQuantity}</div>
                    <div className="text-sm text-gray-500">
                      Reorder: {product.reorderLevel}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="w-full">
                      <Progress value={product.inventoryTurnoverRate} className="h-2 mb-1" />
                      <div className="text-sm text-gray-600">
                        {product.inventoryTurnoverRate}%
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <Badge className={getRiskBadge(product.spoilageRisk)}>
                      {product.spoilageRisk} Risk
                    </Badge>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
