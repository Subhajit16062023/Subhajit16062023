import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { PieChart as PieChartIcon, TrendingUp } from "lucide-react";
import type { Product } from "@shared/schema";

interface ChartsProps {
  products: Product[];
}

const COLORS = ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'];

export function Charts({ products }: ChartsProps) {
  // Category distribution data
  const categoryData = products.reduce((acc, product) => {
    acc[product.category] = (acc[product.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const pieData = Object.entries(categoryData).map(([category, count]) => ({
    name: category,
    value: count,
  }));

  // Spoilage risk trend data (mock data for demonstration)
  const spoilageTrendData = [
    { month: 'Jan', highRisk: 12, mediumRisk: 7, lowRisk: 15 },
    { month: 'Feb', highRisk: 19, mediumRisk: 11, lowRisk: 22 },
    { month: 'Mar', highRisk: 3, mediumRisk: 8, lowRisk: 18 },
    { month: 'Apr', highRisk: 5, mediumRisk: 12, lowRisk: 25 },
    { month: 'May', highRisk: 2, mediumRisk: 15, lowRisk: 30 },
    { month: 'Jun', highRisk: 9, mediumRisk: 6, lowRisk: 28 },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PieChartIcon className="w-5 h-5" />
            Products by Category
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Spoilage Risk Trend
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={spoilageTrendData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="highRisk" 
                stroke="#dc3545" 
                strokeWidth={2}
                name="High Risk"
              />
              <Line 
                type="monotone" 
                dataKey="mediumRisk" 
                stroke="#ffc107" 
                strokeWidth={2}
                name="Medium Risk"
              />
              <Line 
                type="monotone" 
                dataKey="lowRisk" 
                stroke="#198754" 
                strokeWidth={2}
                name="Low Risk"
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
