// This file contains utility functions for data processing
export const calculateDaysUntilExpiration = (expirationDate: string): number => {
  const expDate = new Date(expirationDate);
  const today = new Date();
  const diffTime = expDate.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

export const formatPrice = (price: string): string => {
  // Remove $ sign and convert to number, then format
  const numPrice = parseFloat(price.replace('$', ''));
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(numPrice);
};

export const getExpirationStatus = (expirationDate: string): 'critical' | 'warning' | 'normal' => {
  const days = calculateDaysUntilExpiration(expirationDate);
  if (days <= 7) return 'critical';
  if (days <= 30) return 'warning';
  return 'normal';
};

export const getRiskColor = (risk: string): string => {
  const colors = {
    High: 'text-red-600 bg-red-50',
    Medium: 'text-yellow-600 bg-yellow-50',
    Low: 'text-green-600 bg-green-50',
  };
  return colors[risk as keyof typeof colors] || colors.High;
};
