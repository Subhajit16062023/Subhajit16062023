import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { MetricsCards } from "@/components/metrics-cards";
import { Charts } from "@/components/charts";
import { TemperatureMonitor } from "@/components/temperature-monitor";
import { ProductTable } from "@/components/product-table";
import { Chatbot } from "@/components/chatbot";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Filter, Search } from "lucide-react";
import { useState } from "react";
import type { Product } from "@shared/schema";

export default function Dashboard() {
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [riskFilter, setRiskFilter] = useState("all");

  const { data: products = [], isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const filteredProducts = products.filter(product => {
    return (
      (categoryFilter === "all" || product.category === categoryFilter) &&
      (statusFilter === "all" || product.status === statusFilter) &&
      (riskFilter === "all" || product.spoilageRisk === riskFilter)
    );
  });

  const categories = Array.from(new Set(products.map(p => p.category)));
  const statuses = Array.from(new Set(products.map(p => p.status)));
  const risks = Array.from(new Set(products.map(p => p.spoilageRisk)));

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        <Sidebar />
        
        <div className="flex-1 lg:ml-64">
          <div className="p-6">
            {/* Header */}
            <div className="flex justify-between items-center mb-6">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Store Manager Dashboard</h1>
                <p className="text-gray-600">Monitor inventory, track expiration dates, and analyze waste data</p>
              </div>
              <div className="text-right">
                <small className="text-gray-500">
                  Last Updated: {new Date().toLocaleString()}
                </small>
              </div>
            </div>

            {/* Metrics Cards */}
            <MetricsCards stats={stats} isLoading={statsLoading} />

            {/* Charts */}
            <Charts products={products} />

            {/* Temperature Monitor */}
            <TemperatureMonitor />

            {/* Filter Section */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Filter className="w-5 h-5" />
                  Filter Products
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="All Categories" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {categories.map(category => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="All Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      {statuses.map(status => (
                        <SelectItem key={status} value={status}>
                          {status}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select value={riskFilter} onValueChange={setRiskFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="All Risk Levels" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Risk Levels</SelectItem>
                      {risks.map(risk => (
                        <SelectItem key={risk} value={risk}>
                          {risk} Risk
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Button 
                    onClick={() => {
                      setCategoryFilter("all");
                      setStatusFilter("all");
                      setRiskFilter("all");
                    }}
                    variant="outline"
                  >
                    Clear Filters
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Product Table */}
            <ProductTable products={filteredProducts} isLoading={productsLoading} />
          </div>
        </div>
      </div>

      {/* Chatbot */}
      <Chatbot />
    </div>
  );
}
