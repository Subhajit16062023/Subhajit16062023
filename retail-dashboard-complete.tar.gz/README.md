# Retail Dashboard - Store Manager Application

A comprehensive retail dashboard application built for store managers to monitor inventory, track expiration dates, analyze waste data, and manage environmental conditions. The application features a React frontend with TypeScript, Express.js backend, and includes an integrated chatbot for interactive assistance.

## Features

### 🏪 Dashboard Overview
- **Real-time Metrics**: Monitor total products, high-risk items, turnover rates, and temperature alerts
- **Interactive Charts**: Visualize product distribution by category and spoilage risk trends
- **Responsive Design**: Mobile-first approach with Bootstrap-inspired styling

### 📦 Inventory Management
- **Product Tracking**: Complete product information including stock levels, suppliers, and locations
- **Expiration Monitoring**: Real-time alerts for products approaching expiration dates
- **Smart Filtering**: Filter products by category, status, and spoilage risk levels
- **Reorder Management**: Track reorder levels and quantities

### 🌡️ Temperature Monitoring
- **Environmental Tracking**: Monitor temperature and humidity across different storage areas
- **Alert System**: Visual indicators for normal, alert, and critical conditions
- **Location-based**: Track Cold Storage, Frozen Storage, and Dry Storage conditions

### 🤖 Integrated Chatbot
- **Interactive Assistant**: AI-powered chatbot for inventory queries and guidance
- **Context-aware Responses**: Understands inventory, temperature, and waste management topics
- **Fixed Position**: Accessible from any page via bottom-right corner

### 📊 Data Analytics
- **Waste Analysis**: Historical data analysis for spoilage patterns
- **Turnover Rates**: Track inventory movement and sales performance
- **Risk Assessment**: Categorize products by spoilage risk levels

## Technology Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for fast development and optimized builds
- **Tailwind CSS** with shadcn/ui components
- **TanStack Query** for server state management
- **Wouter** for client-side routing
- **Recharts** for data visualization

### Backend
- **Node.js** with Express.js
- **TypeScript** with ES modules
- **In-memory Storage** for data persistence
- **RESTful API** design with JSON responses

### Development Tools
- **ESLint** for code quality
- **PostCSS** for CSS processing
- **Drizzle ORM** for database schema management

## Installation & Setup

### Prerequisites
- Node.js 18+ 
- npm or yarn package manager

### Quick Start

1. **Extract the project files**
   ```bash
   # Extract the downloaded package
   unzip retail-dashboard.zip
   cd retail-dashboard
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm run dev
   ```

4. **Open your browser**
   Navigate to `http://localhost:5000`

## Project Structure

```
retail-dashboard/
├── client/                    # Frontend React application
│   ├── src/
│   │   ├── components/       # React components
│   │   │   ├── ui/          # Reusable UI components
│   │   │   ├── charts.tsx   # Chart components
│   │   │   ├── chatbot.tsx  # Chatbot interface
│   │   │   └── ...
│   │   ├── pages/           # Page components
│   │   ├── hooks/           # Custom React hooks
│   │   ├── lib/             # Utility functions
│   │   └── main.tsx         # App entry point
│   └── index.html           # HTML template
├── server/                   # Backend Express server
│   ├── index.ts             # Server entry point
│   ├── routes.ts            # API routes
│   ├── storage.ts           # Data storage logic
│   └── vite.ts              # Vite integration
├── shared/                   # Shared types and schemas
│   └── schema.ts            # Database schema definitions
├── package.json             # Dependencies and scripts
└── README.md               # This file
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint

## API Endpoints

### Products
- `GET /api/products` - Get all products
- `GET /api/products/:id` - Get product by ID
- `POST /api/products` - Create new product
- `PUT /api/products/:id` - Update product
- `DELETE /api/products/:id` - Delete product

### Temperature
- `GET /api/temperature/latest` - Get latest temperature readings
- `GET /api/temperature` - Get all temperature readings
- `POST /api/temperature` - Create temperature reading

### Dashboard
- `GET /api/dashboard/stats` - Get dashboard statistics

## Sample Data

The application comes pre-loaded with sample data including:
- 9 products across various categories (Fruits & Vegetables, Dairy, Oils & Fats, etc.)
- Temperature readings for different storage locations
- Realistic inventory data with expiration dates and risk levels

## Configuration

### Environment Variables
- `NODE_ENV` - Environment (development/production)
- `PORT` - Server port (defaults to 5000)

### Customization
- Colors and themes can be modified in `client/src/index.css`
- Component styles use Tailwind CSS classes
- API endpoints can be extended in `server/routes.ts`

## Deployment

### Production Build
```bash
npm run build
```

### Deployment Options
- **Replit**: Ready for deployment on Replit platform
- **Vercel**: Frontend and API routes
- **Netlify**: Static site deployment
- **Railway**: Full-stack deployment

## Features in Detail

### Dashboard Metrics
- **Total Products**: Count of all inventory items
- **High Risk Items**: Products with high spoilage risk
- **Average Turnover Rate**: Inventory movement efficiency
- **Temperature Alerts**: Environmental condition warnings

### Chatbot Capabilities
The integrated chatbot can assist with:
- Inventory level queries
- Expiration date monitoring
- Temperature status updates
- Waste analysis insights
- Product recommendations

### Filtering System
Advanced filtering options include:
- **Category Filter**: Group products by type
- **Status Filter**: Active, Discontinued, Backordered
- **Risk Level Filter**: High, Medium, Low spoilage risk

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

This project is provided as-is for educational and demonstration purposes.

## Support

For questions or issues, please refer to the code comments and documentation within the project files.

---

**Built with ❤️ for retail management efficiency**