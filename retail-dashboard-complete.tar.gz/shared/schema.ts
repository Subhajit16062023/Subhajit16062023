import { pgTable, text, serial, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  productName: text("product_name").notNull(),
  category: text("category").notNull(),
  supplierName: text("supplier_name").notNull(),
  warehouseLocation: text("warehouse_location").notNull(),
  status: text("status").notNull(), // Active, Discontinued, Backordered
  productId: text("product_id").notNull().unique(),
  supplierId: text("supplier_id").notNull(),
  dateReceived: text("date_received").notNull(),
  lastOrderDate: text("last_order_date").notNull(),
  expirationDate: text("expiration_date").notNull(),
  stockQuantity: integer("stock_quantity").notNull(),
  reorderLevel: integer("reorder_level").notNull(),
  reorderQuantity: integer("reorder_quantity").notNull(),
  unitPrice: text("unit_price").notNull(),
  salesVolume: integer("sales_volume").notNull(),
  inventoryTurnoverRate: integer("inventory_turnover_rate").notNull(),
  spoilageRisk: text("spoilage_risk").notNull(), // High, Medium, Low
  shelfLifeDecayPercentage: real("shelf_life_decay_percentage"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const temperatureReadings = pgTable("temperature_readings", {
  id: serial("id").primaryKey(),
  location: text("location").notNull(), // Cold Storage, Frozen Storage, Dry Storage
  temperature: real("temperature").notNull(),
  humidity: real("humidity").notNull(),
  status: text("status").notNull(), // Normal, Alert, Critical
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTemperatureSchema = createInsertSchema(temperatureReadings).omit({
  id: true,
  timestamp: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type TemperatureReading = typeof temperatureReadings.$inferSelect;
export type InsertTemperatureReading = z.infer<typeof insertTemperatureSchema>;
