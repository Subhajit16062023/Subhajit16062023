@echo off
REM Retail Dashboard Setup Script for Windows
REM This script will set up and start the retail dashboard application

echo.
echo 🏪 Retail Dashboard Setup Script
echo =================================
echo.

REM Check if Node.js is installed
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed!
    echo [INFO] Please install Node.js 18+ from https://nodejs.org
    pause
    exit /b 1
)

echo [INFO] Node.js is installed
node --version

REM Check if npm is installed
npm --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] npm is not installed!
    echo [INFO] Please install npm (usually comes with Node.js)
    pause
    exit /b 1
)

echo [INFO] npm is installed
npm --version

echo.
echo [STEP] Installing dependencies...
echo.

REM Install dependencies
npm install
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install dependencies
    pause
    exit /b 1
)

echo.
echo [INFO] Dependencies installed successfully!
echo [INFO] Setup completed successfully!
echo.
echo [INFO] Features available:
echo   • Dashboard with real-time metrics
echo   • Product inventory management
echo   • Temperature monitoring
echo   • Interactive chatbot
echo   • Data visualization charts
echo.
echo [INFO] The application will be available at: http://localhost:5000
echo [INFO] Press Ctrl+C to stop the server
echo.

pause

echo [STEP] Starting the retail dashboard...
echo.

REM Start the application
npm run dev

pause