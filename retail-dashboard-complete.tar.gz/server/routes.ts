import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProductSchema, insertTemperatureSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Product routes
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const product = await storage.getProduct(id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  app.post("/api/products", async (req, res) => {
    try {
      const validatedData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(validatedData);
      res.status(201).json(product);
    } catch (error) {
      res.status(400).json({ error: "Invalid product data" });
    }
  });

  app.put("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertProductSchema.partial().parse(req.body);
      const product = await storage.updateProduct(id, validatedData);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(400).json({ error: "Invalid product data" });
    }
  });

  app.delete("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteProduct(id);
      if (!deleted) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete product" });
    }
  });

  // Temperature routes
  app.get("/api/temperature/latest", async (req, res) => {
    try {
      const readings = await storage.getLatestTemperatureReadings();
      res.json(readings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch temperature readings" });
    }
  });

  app.get("/api/temperature", async (req, res) => {
    try {
      const readings = await storage.getAllTemperatureReadings();
      res.json(readings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch temperature readings" });
    }
  });

  app.post("/api/temperature", async (req, res) => {
    try {
      const validatedData = insertTemperatureSchema.parse(req.body);
      const reading = await storage.createTemperatureReading(validatedData);
      res.status(201).json(reading);
    } catch (error) {
      res.status(400).json({ error: "Invalid temperature data" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      const totalProducts = products.length;
      const highRiskItems = products.filter(p => p.spoilageRisk === "High").length;
      const avgTurnoverRate = Math.round(
        products.reduce((sum, p) => sum + p.inventoryTurnoverRate, 0) / products.length
      );
      
      const temperatureReadings = await storage.getLatestTemperatureReadings();
      const temperatureAlerts = temperatureReadings.filter(r => r.status === "Alert").length;

      res.json({
        totalProducts,
        highRiskItems,
        avgTurnoverRate,
        temperatureAlerts,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
