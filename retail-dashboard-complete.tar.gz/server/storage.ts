import { users, products, temperatureReadings, type User, type InsertUser, type Product, type InsertProduct, type TemperatureReading, type InsertTemperatureReading } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getProductByProductId(productId: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  
  getAllTemperatureReadings(): Promise<TemperatureReading[]>;
  getLatestTemperatureReadings(): Promise<TemperatureReading[]>;
  createTemperatureReading(reading: InsertTemperatureReading): Promise<TemperatureReading>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private products: Map<number, Product>;
  private temperatureReadings: Map<number, TemperatureReading>;
  private currentUserId: number;
  private currentProductId: number;
  private currentTempId: number;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.temperatureReadings = new Map();
    this.currentUserId = 1;
    this.currentProductId = 1;
    this.currentTempId = 1;
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample product data from the request
    const sampleProducts = [
      {
        productName: "Bell Pepper",
        category: "Fruits & Vegetables",
        supplierName: "Eimbee",
        warehouseLocation: "20 Pennsylvania Parkway",
        status: "Discontinued",
        productId: "29-017-6255",
        supplierId: "43-348-2450",
        dateReceived: "03-01-2024",
        lastOrderDate: "01-06-2025",
        expirationDate: "1/31/2025",
        stockQuantity: 46,
        reorderLevel: 64,
        reorderQuantity: 17,
        unitPrice: "$4.60",
        salesVolume: 96,
        inventoryTurnoverRate: 55,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: null,
      },
      {
        productName: "Vegetable Oil",
        category: "Oils & Fats",
        supplierName: "Digitube",
        warehouseLocation: "03643 Oakridge Lane",
        status: "Backordered",
        productId: "79-569-8856",
        supplierId: "04-854-7165",
        dateReceived: "04-01-2024",
        lastOrderDate: "5/19/2024",
        expirationDate: "06-11-2024",
        stockQuantity: 51,
        reorderLevel: 87,
        reorderQuantity: 86,
        unitPrice: "$2.00",
        salesVolume: 24,
        inventoryTurnoverRate: 83,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: 10,
      },
      {
        productName: "Parmesan Cheese",
        category: "Dairy",
        supplierName: "BlogXS",
        warehouseLocation: "73 Graedel Street",
        status: "Discontinued",
        productId: "28-146-2641",
        supplierId: "82-995-0739",
        dateReceived: "04-01-2024",
        lastOrderDate: "12/21/2024",
        expirationDate: "04-08-2024",
        stockQuantity: 38,
        reorderLevel: 67,
        reorderQuantity: 66,
        unitPrice: "$12.00",
        salesVolume: 35,
        inventoryTurnoverRate: 24,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: null,
      },
      {
        productName: "Carrot",
        category: "Fruits & Vegetables",
        supplierName: "Avaveo",
        warehouseLocation: "44801 Myrtle Center",
        status: "Discontinued",
        productId: "11-581-9869",
        supplierId: "22-867-3079",
        dateReceived: "05-01-2024",
        lastOrderDate: "12-12-2024",
        expirationDate: "9/26/2024",
        stockQuantity: 51,
        reorderLevel: 60,
        reorderQuantity: 98,
        unitPrice: "$1.50",
        salesVolume: 44,
        inventoryTurnoverRate: 95,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: null,
      },
      {
        productName: "Garlic",
        category: "Fruits & Vegetables",
        supplierName: "Katz",
        warehouseLocation: "6195 Monterey Center",
        status: "Discontinued",
        productId: "13-202-4809",
        supplierId: "24-281-7685",
        dateReceived: "05-01-2024",
        lastOrderDate: "7/28/2024",
        expirationDate: "5/20/2024",
        stockQuantity: 27,
        reorderLevel: 22,
        reorderQuantity: 89,
        unitPrice: "$7.00",
        salesVolume: 91,
        inventoryTurnoverRate: 77,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: null,
      },
      {
        productName: "Lemon",
        category: "Fruits & Vegetables",
        supplierName: "Yata",
        warehouseLocation: "5141 Anniversary Crossing",
        status: "Backordered",
        productId: "70-145-2550",
        supplierId: "75-849-4524",
        dateReceived: "05-01-2024",
        lastOrderDate: "08-07-2024",
        expirationDate: "08-06-2024",
        stockQuantity: 91,
        reorderLevel: 6,
        reorderQuantity: 37,
        unitPrice: "$2.40",
        salesVolume: 38,
        inventoryTurnoverRate: 70,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: 10,
      },
      {
        productName: "Coconut Sugar",
        category: "Grains & Pulses",
        supplierName: "Lazz",
        warehouseLocation: "38583 2nd Pass",
        status: "Active",
        productId: "10-626-8536",
        supplierId: "23-274-3305",
        dateReceived: "05-01-2024",
        lastOrderDate: "1/29/2025",
        expirationDate: "3/30/2024",
        stockQuantity: 17,
        reorderLevel: 85,
        reorderQuantity: 74,
        unitPrice: "$5.00",
        salesVolume: 76,
        inventoryTurnoverRate: 89,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: 20,
      },
      {
        productName: "Anchovies",
        category: "Seafood",
        supplierName: "Zoonder",
        warehouseLocation: "86 Porter Junction",
        status: "Discontinued",
        productId: "42-879-9478",
        supplierId: "00-900-0119",
        dateReceived: "06-01-2024",
        lastOrderDate: "2/23/2025",
        expirationDate: "8/22/2024",
        stockQuantity: 81,
        reorderLevel: 22,
        reorderQuantity: 20,
        unitPrice: "$10.00",
        salesVolume: 95,
        inventoryTurnoverRate: 77,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: null,
      },
      {
        productName: "Cheese",
        category: "Dairy",
        supplierName: "Oozz",
        warehouseLocation: "05518 Saint Paul Street",
        status: "Active",
        productId: "82-380-5378",
        supplierId: "96-353-3049",
        dateReceived: "06-01-2024",
        lastOrderDate: "06-03-2024",
        expirationDate: "03-07-2024",
        stockQuantity: 78,
        reorderLevel: 24,
        reorderQuantity: 31,
        unitPrice: "$9.00",
        salesVolume: 60,
        inventoryTurnoverRate: 41,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: 20,
      }
    ];

    sampleProducts.forEach(product => {
      const fullProduct: Product = {
        id: this.currentProductId++,
        ...product,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.products.set(fullProduct.id, fullProduct);
    });

    // Sample temperature readings
    const sampleTemperatureReadings = [
      {
        location: "Cold Storage",
        temperature: 4.2,
        humidity: 65,
        status: "Normal",
      },
      {
        location: "Frozen Storage",
        temperature: -18.5,
        humidity: 45,
        status: "Normal",
      },
      {
        location: "Dry Storage",
        temperature: 22.1,
        humidity: 55,
        status: "Alert",
      },
    ];

    sampleTemperatureReadings.forEach(reading => {
      const fullReading: TemperatureReading = {
        id: this.currentTempId++,
        ...reading,
        timestamp: new Date(),
      };
      this.temperatureReadings.set(fullReading.id, fullReading);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductByProductId(productId: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(
      (product) => product.productId === productId,
    );
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    const product: Product = {
      ...insertProduct,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: number, updateData: Partial<InsertProduct>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;

    const updatedProduct: Product = {
      ...product,
      ...updateData,
      updatedAt: new Date(),
    };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }

  async getAllTemperatureReadings(): Promise<TemperatureReading[]> {
    return Array.from(this.temperatureReadings.values());
  }

  async getLatestTemperatureReadings(): Promise<TemperatureReading[]> {
    const readings = Array.from(this.temperatureReadings.values());
    const locationMap = new Map<string, TemperatureReading>();
    
    readings.forEach(reading => {
      const existing = locationMap.get(reading.location);
      if (!existing || reading.timestamp > existing.timestamp) {
        locationMap.set(reading.location, reading);
      }
    });

    return Array.from(locationMap.values());
  }

  async createTemperatureReading(insertReading: InsertTemperatureReading): Promise<TemperatureReading> {
    const id = this.currentTempId++;
    const reading: TemperatureReading = {
      ...insertReading,
      id,
      timestamp: new Date(),
    };
    this.temperatureReadings.set(id, reading);
    return reading;
  }
}

export const storage = new MemStorage();
