#!/bin/bash

# Retail Dashboard Setup Script
# This script will set up and start the retail dashboard application

echo "🏪 Retail Dashboard Setup Script"
echo "================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

# Check if Node.js is installed
check_nodejs() {
    if ! command -v node &> /dev/null; then
        print_error "Node.js is not installed!"
        print_status "Please install Node.js 18+ from https://nodejs.org"
        exit 1
    fi
    
    NODE_VERSION=$(node --version)
    print_status "Node.js version: $NODE_VERSION"
}

# Check if npm is installed
check_npm() {
    if ! command -v npm &> /dev/null; then
        print_error "npm is not installed!"
        print_status "Please install npm (usually comes with Node.js)"
        exit 1
    fi
    
    NPM_VERSION=$(npm --version)
    print_status "npm version: $NPM_VERSION"
}

# Install dependencies
install_dependencies() {
    print_step "Installing dependencies..."
    
    if npm install; then
        print_status "Dependencies installed successfully!"
    else
        print_error "Failed to install dependencies"
        exit 1
    fi
}

# Check if port 5000 is available
check_port() {
    if lsof -i :5000 &> /dev/null; then
        print_warning "Port 5000 is already in use"
        print_status "You can kill the process with: npx kill-port 5000"
        print_status "Or the application will try to use a different port"
    else
        print_status "Port 5000 is available"
    fi
}

# Start the application
start_application() {
    print_step "Starting the retail dashboard..."
    print_status "The application will be available at: http://localhost:5000"
    print_status "Press Ctrl+C to stop the server"
    echo ""
    
    npm run dev
}

# Main execution
main() {
    echo ""
    print_step "Checking system requirements..."
    check_nodejs
    check_npm
    
    echo ""
    print_step "Checking port availability..."
    check_port
    
    echo ""
    install_dependencies
    
    echo ""
    print_status "Setup completed successfully!"
    print_status "Features available:"
    print_status "  • Dashboard with real-time metrics"
    print_status "  • Product inventory management"
    print_status "  • Temperature monitoring"
    print_status "  • Interactive chatbot"
    print_status "  • Data visualization charts"
    
    echo ""
    read -p "Press Enter to start the application..."
    
    start_application
}

# Run the main function
main