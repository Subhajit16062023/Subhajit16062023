# Installation Guide - Retail Dashboard

## Quick Start Guide

### 1. Prerequisites
Before installing, ensure you have:
- **Node.js 18+** (Download from https://nodejs.org)
- **npm** (comes with Node.js)

To check if you have Node.js installed:
```bash
node --version
npm --version
```

### 2. Installation Steps

#### Step 1: Extract the Package
```bash
# Extract the downloaded zip file
unzip retail-dashboard.zip
cd retail-dashboard
```

#### Step 2: Install Dependencies
```bash
# Install all required packages
npm install
```

#### Step 3: Start the Application
```bash
# Start the development server
npm run dev
```

#### Step 4: Access the Dashboard
Open your web browser and navigate to:
```
http://localhost:5000
```

## What You'll See

### Dashboard Features
1. **Sidebar Navigation** - Navigate between different sections
2. **Metrics Cards** - Key performance indicators at the top
3. **Charts** - Visual data representation
4. **Temperature Monitor** - Environmental conditions
5. **Product Table** - Detailed inventory listing
6. **Chatbot** - Interactive assistant (bottom-right corner)

### Sample Data Included
- 9 products with realistic inventory data
- Temperature readings for different storage areas
- Expiration dates and risk assessments
- Supplier and location information

## Troubleshooting

### Common Issues

#### Port Already in Use
If you see "Port 5000 is already in use":
```bash
# Kill the process using port 5000
npx kill-port 5000
# Or use a different port
PORT=3000 npm run dev
```

#### Module Not Found Errors
If you get module errors:
```bash
# Clear npm cache and reinstall
npm cache clean --force
rm -rf node_modules package-lock.json
npm install
```

#### Permission Errors (Windows)
Run your terminal as Administrator or use:
```bash
npm install --no-optional
```

### Browser Requirements
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Development Mode

### File Structure
```
retail-dashboard/
├── client/          # Frontend React app
├── server/          # Backend Express server
├── shared/          # Shared TypeScript types
├── package.json     # Dependencies
└── README.md        # Documentation
```

### Available Commands
```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run preview      # Preview production build
```

## Production Deployment

### Build for Production
```bash
npm run build
```

### Environment Variables
Create a `.env` file in the root directory:
```
NODE_ENV=production
PORT=5000
```

### Deployment Platforms
- **Replit**: Click "Deploy" button
- **Vercel**: Connect to GitHub repository
- **Netlify**: Upload build folder
- **Railway**: Connect to GitHub

## Support

### Getting Help
1. Check the browser console for errors (F12)
2. Verify all dependencies are installed
3. Ensure Node.js version is 18+
4. Check firewall settings for port 5000

### Features to Explore
1. **Filter Products** - Use dropdowns to filter by category, status, or risk
2. **Chat with Assistant** - Click the blue chat button in bottom-right
3. **View Charts** - Interactive pie chart and trend analysis
4. **Monitor Temperature** - Real-time environmental conditions

---

**Need help? Check the README.md for detailed documentation.**