import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertProductSchema, insertTemperatureSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Product routes
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const product = await storage.getProduct(id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  app.post("/api/products", async (req, res) => {
    try {
      const validatedData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(validatedData);
      res.status(201).json(product);
    } catch (error) {
      res.status(400).json({ error: "Invalid product data" });
    }
  });

  app.put("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertProductSchema.partial().parse(req.body);
      const product = await storage.updateProduct(id, validatedData);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(400).json({ error: "Invalid product data" });
    }
  });

  app.delete("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteProduct(id);
      if (!deleted) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete product" });
    }
  });

  // Temperature routes
  app.get("/api/temperature/latest", async (req, res) => {
    try {
      const readings = await storage.getLatestTemperatureReadings();
      res.json(readings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch temperature readings" });
    }
  });

  app.get("/api/temperature", async (req, res) => {
    try {
      const readings = await storage.getAllTemperatureReadings();
      res.json(readings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch temperature readings" });
    }
  });

  app.post("/api/temperature", async (req, res) => {
    try {
      const validatedData = insertTemperatureSchema.parse(req.body);
      const reading = await storage.createTemperatureReading(validatedData);
      res.status(201).json(reading);
    } catch (error) {
      res.status(400).json({ error: "Invalid temperature data" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      const totalProducts = products.length;
      const highRiskItems = products.filter(p => p.spoilageRisk === "High").length;
      const avgTurnoverRate = Math.round(
        products.reduce((sum, p) => sum + p.inventoryTurnoverRate, 0) / products.length
      );
      
      const temperatureReadings = await storage.getLatestTemperatureReadings();
      const temperatureAlerts = temperatureReadings.filter(r => r.status === "Alert").length;

      res.json({
        totalProducts,
        highRiskItems,
        avgTurnoverRate,
        temperatureAlerts,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  
  // Create WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Handle WebSocket connections
  wss.on('connection', (ws) => {
    console.log('New WebSocket connection');
    
    // Send welcome message
    ws.send(JSON.stringify({
      type: 'system_message',
      message: 'Connected to retail dashboard WebSocket'
    }));
    
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        if (data.type === 'chat_message') {
          // Handle chat messages
          const response = generateChatResponse(data.message);
          ws.send(JSON.stringify({
            type: 'chat_response',
            message: response,
            timestamp: new Date().toISOString()
          }));
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });
    
    ws.on('close', () => {
      console.log('WebSocket connection closed');
    });
  });
  
  // Broadcast updates to all connected clients
  function broadcast(message: any) {
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    });
  }
  
  // Chat response generator
  function generateChatResponse(message: string): string {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('inventory') || lowerMessage.includes('stock')) {
      return "I can help you check current inventory levels. You have 9 products in your system with varying stock levels. Several items like Bell Pepper (46 units, reorder level: 64) and Coconut Sugar (17 units, reorder level: 85) are below reorder levels and need restocking.";
    }
    
    if (lowerMessage.includes('expiration') || lowerMessage.includes('expire')) {
      return "Several items have concerning expiration dates. Bell Pepper expires on 1/31/2025, and multiple products from your Fruits & Vegetables category need immediate attention. I recommend prioritizing these items for sale or promotion.";
    }
    
    if (lowerMessage.includes('temperature') || lowerMessage.includes('temp')) {
      return "Current temperature status: Cold Storage is at 4.2°C (Normal), Frozen Storage at -18.5°C (Normal), and Dry Storage at 22.1°C with Alert status. The Dry Storage humidity levels may need attention.";
    }
    
    if (lowerMessage.includes('risk') || lowerMessage.includes('spoilage')) {
      return "You currently have 9 high-risk items in your inventory, including Bell Pepper, Vegetable Oil, Parmesan Cheese, Carrot, Garlic, Lemon, Coconut Sugar, Anchovies, and Cheese. These items need immediate attention to prevent spoilage.";
    }
    
    if (lowerMessage.includes('waste') || lowerMessage.includes('analysis')) {
      return "Waste analysis shows that your Fruits & Vegetables category has the highest spoilage risk. Consider implementing a first-in-first-out (FIFO) system and adjusting order quantities based on historical turnover rates.";
    }
    
    if (lowerMessage.includes('alert') || lowerMessage.includes('notification')) {
      return "Current alerts: 1 temperature alert in Dry Storage, 9 high-risk items for spoilage, and 3 products expiring within the next 30 days. I recommend immediate action on these items.";
    }
    
    if (lowerMessage.includes('turnover') || lowerMessage.includes('sales')) {
      return "Turnover analysis shows Carrot (95%) and Coconut Sugar (89%) have high turnover rates, while Parmesan Cheese (24%) has low turnover. Consider adjusting orders based on these performance metrics.";
    }
    
    if (lowerMessage.includes('help') || lowerMessage.includes('what can you do')) {
      return "I can assist with: 📊 Inventory management and stock levels, ⏰ Expiration date monitoring, 🌡️ Temperature alerts and environmental conditions, 🗑️ Waste analysis and spoilage prevention, 📈 Sales analytics and turnover rates, 🔔 Real-time alerts and notifications. What would you like to explore?";
    }
    
    return "I'm your retail assistant! I can help with inventory management, expiration monitoring, temperature alerts, waste analysis, and sales analytics. What specific information do you need about your store operations?";
  }
  
  return httpServer;
}
