#!/bin/bash

# Setup script for HTML/CSS/JavaScript Retail Dashboard
echo "🚀 Setting up HTML/CSS/JavaScript Retail Dashboard..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    echo "Visit: https://nodejs.org/"
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed. Please install npm first."
    exit 1
fi

echo "✅ Node.js version: $(node --version)"
echo "✅ npm version: $(npm --version)"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Check if installation was successful
if [ $? -eq 0 ]; then
    echo "✅ Dependencies installed successfully!"
else
    echo "❌ Failed to install dependencies."
    exit 1
fi

# Create logs directory if it doesn't exist
mkdir -p logs

# Display completion message
echo ""
echo "🎉 Setup completed successfully!"
echo ""
echo "To start the application:"
echo "  npm run dev"
echo ""
echo "Then open your browser and navigate to:"
echo "  http://localhost:5000"
echo ""
echo "Features included:"
echo "  📊 Interactive Dashboard with real-time metrics"
echo "  🗂️ Inventory Management with filtering"
echo "  🌡️ Temperature Monitoring"
echo "  🤖 AI-Powered Chatbot with WebSocket support"
echo "  📱 Responsive Design for all devices"
echo ""
echo "For more information, see README-html.md"
echo ""