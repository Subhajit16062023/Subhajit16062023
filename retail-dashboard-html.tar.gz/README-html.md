# Retail Dashboard - HTML/CSS/JavaScript Version

A comprehensive retail dashboard built with vanilla HTML, CSS, and JavaScript, featuring WebSocket-powered chatbot functionality for store inventory management.

## Features

### 📊 Dashboard Overview
- **Metrics Cards**: Total products, high-risk items, average turnover rate, temperature alerts
- **Interactive Charts**: Category distribution (pie chart) and spoilage risk trends (line chart)
- **Real-time Updates**: Automatic data refresh every 30 seconds

### 🗂️ Inventory Management
- **Product Table**: Complete product listing with filtering and sorting
- **Stock Monitoring**: Current stock levels with reorder alerts
- **Expiration Tracking**: Visual warnings for products nearing expiration
- **Risk Assessment**: High/Medium/Low spoilage risk indicators

### 🌡️ Temperature Monitoring
- **Multi-zone Tracking**: Cold Storage, Frozen Storage, Dry Storage
- **Real-time Alerts**: Temperature and humidity monitoring
- **Status Indicators**: Normal, Alert, and Critical status levels

### 🤖 AI-Powered Chatbot
- **WebSocket Connection**: Real-time chat functionality
- **Context-Aware Responses**: Understands inventory, expiration, temperature queries
- **Offline Mode**: Fallback responses when WebSocket is unavailable
- **Interactive Interface**: Bottom-right chat window with conversation history

### 📱 Responsive Design
- **Mobile-First**: Optimized for tablets and smartphones
- **Bootstrap 5**: Modern, responsive UI components
- **Sidebar Navigation**: Collapsible navigation menu
- **Adaptive Layout**: Automatically adjusts to screen size

## Technology Stack

### Frontend
- **HTML5**: Semantic markup structure
- **CSS3**: Custom styling with animations and responsive design
- **JavaScript ES6+**: Modern JavaScript features
- **Bootstrap 5**: CSS framework for responsive components
- **Chart.js**: Interactive charts and data visualization
- **Font Awesome**: Icons and visual elements

### Backend
- **Node.js**: Server runtime
- **Express.js**: Web framework
- **WebSocket (ws)**: Real-time communication
- **TypeScript**: Type safety and better development experience

## Installation & Setup

### Prerequisites
- Node.js (v16 or higher)
- npm or yarn package manager

### Quick Start
1. **Clone or Download** the project files
2. **Install Dependencies**:
   ```bash
   npm install
   ```
3. **Start the Application**:
   ```bash
   npm run dev
   ```
4. **Open Browser** and navigate to `http://localhost:5000`

### Project Structure
```
├── index.html          # Main HTML file
├── style.css           # Custom CSS styles
├── data.js            # Sample data and utility functions
├── dashboard.js       # Main application logic
├── websocket.js       # WebSocket client implementation
├── server/
│   ├── index.ts       # Express server setup
│   ├── routes.ts      # API routes and WebSocket server
│   └── storage.ts     # In-memory data storage
└── README-html.md     # This documentation
```

## Features in Detail

### Dashboard Metrics
- **Total Products**: Current inventory count
- **High-Risk Items**: Products with spoilage risk
- **Average Turnover**: Overall inventory performance
- **Temperature Alerts**: Environmental monitoring status

### Product Management
- **Filtering**: By category, status, and risk level
- **Stock Actions**: View details and add stock
- **Expiration Warnings**: Visual alerts for items nearing expiration
- **Turnover Analysis**: Performance metrics with progress bars

### Temperature Monitoring
Real-time monitoring of three storage zones:
- **Cold Storage**: 0-8°C optimal range
- **Frozen Storage**: Below -15°C
- **Dry Storage**: 15-25°C with humidity control

### Chatbot Capabilities
The AI assistant can help with:
- **Inventory Queries**: "What's my current stock level?"
- **Expiration Alerts**: "Which items expire soon?"
- **Temperature Status**: "How are the storage temperatures?"
- **Risk Assessment**: "Show me high-risk items"
- **Waste Analysis**: "What's my spoilage rate?"
- **Sales Analytics**: "Which products have high turnover?"

### WebSocket Implementation
- **Real-time Communication**: Instant message delivery
- **Auto-reconnection**: Attempts to reconnect on disconnection
- **Fallback Mode**: Offline responses when server unavailable
- **Message Queue**: Handles messages during reconnection

## Data Structure

### Product Data
```javascript
{
  id: 1,
  productName: "Bell Pepper",
  category: "Fruits & Vegetables",
  status: "Active",
  expirationDate: "1/31/2025",
  stockQuantity: 46,
  reorderLevel: 64,
  spoilageRisk: "High",
  inventoryTurnoverRate: 55
}
```

### Temperature Data
```javascript
{
  location: "Cold Storage",
  temperature: 4.2,
  humidity: 65,
  status: "Normal"
}
```

## Customization

### Adding New Products
Modify the `sampleProducts` array in `data.js`:
```javascript
const sampleProducts = [
  {
    // Add your product data here
  }
];
```

### Customizing Chatbot Responses
Edit the `generateChatResponse` function in `server/routes.ts`:
```javascript
function generateChatResponse(message: string): string {
  // Add your custom response logic
}
```

### Styling Modifications
Update `style.css` to customize:
- Color scheme and branding
- Layout and spacing
- Animations and transitions
- Responsive breakpoints

## Browser Compatibility
- **Chrome**: 90+
- **Firefox**: 88+
- **Safari**: 14+
- **Edge**: 90+
- **Mobile**: iOS Safari 14+, Android Chrome 90+

## Performance Features
- **Efficient Rendering**: Minimal DOM manipulation
- **Lazy Loading**: Charts render only when needed
- **Debounced Updates**: Prevents excessive re-renders
- **Memory Management**: Proper cleanup of event listeners

## Security Considerations
- **Input Validation**: All user inputs are sanitized
- **WebSocket Security**: Proper message validation
- **XSS Prevention**: Content is properly escaped
- **CORS Configuration**: Appropriate cross-origin settings

## Troubleshooting

### Common Issues
1. **WebSocket Connection Fails**:
   - Check if the server is running
   - Verify the WebSocket URL in `websocket.js`
   - Ensure firewall allows WebSocket connections

2. **Charts Not Displaying**:
   - Verify Chart.js is loaded correctly
   - Check browser console for JavaScript errors
   - Ensure canvas elements have proper dimensions

3. **Data Not Loading**:
   - Confirm `data.js` is included in HTML
   - Check for syntax errors in JavaScript files
   - Verify sample data format is correct

### Development Tips
- Use browser developer tools for debugging
- Check Network tab for WebSocket connection status
- Monitor Console for JavaScript errors
- Test responsive design using device emulation

## Future Enhancements
- **Database Integration**: Replace in-memory storage with PostgreSQL
- **User Authentication**: Add login and user management
- **Push Notifications**: Browser notifications for alerts
- **Export Functions**: PDF and Excel report generation
- **Advanced Analytics**: Predictive inventory analysis
- **Multi-store Support**: Manage multiple store locations

## License
This project is provided as-is for educational and demonstration purposes.

## Support
For technical support or questions about implementation, please refer to the code comments and documentation within the source files.