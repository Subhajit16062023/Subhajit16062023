// Dashboard functionality
let currentProducts = [...sampleProducts];
let categoryChart = null;
let spoilageChart = null;

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
    setupEventListeners();
    updateLastUpdated();
});

function initializeDashboard() {
    updateMetrics();
    populateFilters();
    renderProductsTable();
    initializeCharts();
    updateTemperatureDisplay();
}

function setupEventListeners() {
    // Filter event listeners
    document.getElementById('categoryFilter').addEventListener('change', filterProducts);
    document.getElementById('statusFilter').addEventListener('change', filterProducts);
    document.getElementById('riskFilter').addEventListener('change', filterProducts);
    document.getElementById('clearFilters').addEventListener('click', clearFilters);
    
    // Chatbot event listeners
    document.getElementById('chatbotToggle').addEventListener('click', toggleChatbot);
    document.getElementById('closeChatbot').addEventListener('click', closeChatbot);
    document.getElementById('sendMessage').addEventListener('click', sendChatMessage);
    document.getElementById('chatInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendChatMessage();
        }
    });
}

function updateMetrics() {
    const totalProducts = currentProducts.length;
    const highRiskItems = currentProducts.filter(p => p.spoilageRisk === 'High').length;
    const avgTurnover = Math.round(
        currentProducts.reduce((sum, p) => sum + p.inventoryTurnoverRate, 0) / currentProducts.length
    );
    const tempAlerts = temperatureData.filter(t => t.status === 'Alert').length;
    
    document.getElementById('totalProducts').textContent = totalProducts;
    document.getElementById('highRiskItems').textContent = highRiskItems;
    document.getElementById('avgTurnover').textContent = avgTurnover + '%';
    document.getElementById('tempAlerts').textContent = tempAlerts;
}

function populateFilters() {
    const categories = getUniqueCategories(currentProducts);
    const categoryFilter = document.getElementById('categoryFilter');
    
    // Clear existing options except the first one
    categoryFilter.innerHTML = '<option value="">All Categories</option>';
    categories.forEach(category => {
        const option = document.createElement('option');
        option.value = category;
        option.textContent = category;
        categoryFilter.appendChild(option);
    });
}

function filterProducts() {
    const categoryFilter = document.getElementById('categoryFilter').value;
    const statusFilter = document.getElementById('statusFilter').value;
    const riskFilter = document.getElementById('riskFilter').value;
    
    const filteredProducts = sampleProducts.filter(product => {
        const categoryMatch = !categoryFilter || product.category === categoryFilter;
        const statusMatch = !statusFilter || product.status === statusFilter;
        const riskMatch = !riskFilter || product.spoilageRisk === riskFilter;
        return categoryMatch && statusMatch && riskMatch;
    });
    
    currentProducts = filteredProducts;
    renderProductsTable();
    updateMetrics();
}

function clearFilters() {
    document.getElementById('categoryFilter').value = '';
    document.getElementById('statusFilter').value = '';
    document.getElementById('riskFilter').value = '';
    
    currentProducts = [...sampleProducts];
    renderProductsTable();
    updateMetrics();
}

function renderProductsTable() {
    const tbody = document.getElementById('productsTableBody');
    tbody.innerHTML = '';
    
    currentProducts.forEach(product => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>
                <div>
                    <div class="fw-bold">${product.productName}</div>
                    <small class="text-muted">${product.productId}</small>
                </div>
            </td>
            <td>${product.category}</td>
            <td>
                <span class="badge ${getStatusBadgeClass(product.status)}">${product.status}</span>
            </td>
            <td>
                <div>${product.expirationDate}</div>
                ${getExpirationWarning(product.expirationDate)}
            </td>
            <td>
                <div class="fw-bold">${product.stockQuantity}</div>
                <small class="text-muted">Reorder: ${product.reorderLevel}</small>
            </td>
            <td>
                <div class="progress mb-1" style="height: 6px;">
                    <div class="progress-bar" role="progressbar" style="width: ${product.inventoryTurnoverRate}%"></div>
                </div>
                <small class="text-muted">${product.inventoryTurnoverRate}%</small>
            </td>
            <td>
                <span class="badge ${getRiskBadgeClass(product.spoilageRisk)}">${product.spoilageRisk} Risk</span>
            </td>
            <td>
                <button class="btn btn-sm btn-outline-primary me-1" onclick="viewProduct(${product.id})">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-sm btn-outline-success" onclick="addStock(${product.id})">
                    <i class="fas fa-plus"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function initializeCharts() {
    initializeCategoryChart();
    initializeSpoilageChart();
}

function initializeCategoryChart() {
    const ctx = document.getElementById('categoryChart').getContext('2d');
    
    // Calculate category distribution
    const categoryData = currentProducts.reduce((acc, product) => {
        acc[product.category] = (acc[product.category] || 0) + 1;
        return acc;
    }, {});
    
    const labels = Object.keys(categoryData);
    const data = Object.values(categoryData);
    const colors = ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'];
    
    if (categoryChart) {
        categoryChart.destroy();
    }
    
    categoryChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: colors.slice(0, labels.length),
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

function initializeSpoilageChart() {
    const ctx = document.getElementById('spoilageChart').getContext('2d');
    
    if (spoilageChart) {
        spoilageChart.destroy();
    }
    
    spoilageChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: spoilageTrendData.map(d => d.month),
            datasets: [
                {
                    label: 'High Risk',
                    data: spoilageTrendData.map(d => d.highRisk),
                    borderColor: '#e74c3c',
                    backgroundColor: 'rgba(231, 76, 60, 0.1)',
                    tension: 0.4
                },
                {
                    label: 'Medium Risk',
                    data: spoilageTrendData.map(d => d.mediumRisk),
                    borderColor: '#f39c12',
                    backgroundColor: 'rgba(243, 156, 18, 0.1)',
                    tension: 0.4
                },
                {
                    label: 'Low Risk',
                    data: spoilageTrendData.map(d => d.lowRisk),
                    borderColor: '#27ae60',
                    backgroundColor: 'rgba(39, 174, 96, 0.1)',
                    tension: 0.4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

function updateTemperatureDisplay() {
    temperatureData.forEach((temp, index) => {
        const locations = ['cold', 'frozen', 'dry'];
        const location = locations[index];
        
        if (location) {
            document.getElementById(`${location}Temp`).textContent = `${temp.temperature}°C`;
            document.getElementById(`${location}Humidity`).textContent = `${temp.humidity}%`;
            
            const statusElement = document.getElementById(`${location}Status`);
            statusElement.textContent = temp.status;
            statusElement.className = `temp-status ${temp.status.toLowerCase()}`;
        }
    });
}

function updateLastUpdated() {
    document.getElementById('lastUpdated').textContent = new Date().toLocaleString();
}

// Chatbot functions
function toggleChatbot() {
    const chatbotContainer = document.getElementById('chatbotContainer');
    chatbotContainer.classList.toggle('active');
}

function closeChatbot() {
    const chatbotContainer = document.getElementById('chatbotContainer');
    chatbotContainer.classList.remove('active');
}

function sendChatMessage() {
    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    
    if (message) {
        // Display user message
        if (chatbotWS && chatbotWS.displayUserMessage) {
            chatbotWS.displayUserMessage(message);
        }
        
        // Send message via WebSocket or handle offline
        if (chatbotWS && chatbotWS.sendMessage) {
            chatbotWS.sendMessage(message);
        }
        
        input.value = '';
    }
}

// Product action functions
function viewProduct(productId) {
    const product = currentProducts.find(p => p.id === productId);
    if (product) {
        alert(`Product Details:\n\nName: ${product.productName}\nCategory: ${product.category}\nStock: ${product.stockQuantity}\nExpiration: ${product.expirationDate}\nRisk Level: ${product.spoilageRisk}`);
    }
}

function addStock(productId) {
    const product = currentProducts.find(p => p.id === productId);
    if (product) {
        const additionalStock = prompt(`Add stock for ${product.productName}:\nCurrent stock: ${product.stockQuantity}`, '10');
        if (additionalStock && !isNaN(additionalStock)) {
            product.stockQuantity += parseInt(additionalStock);
            renderProductsTable();
            updateMetrics();
            
            // Send update to chatbot if connected
            if (chatbotWS && chatbotWS.handleSystemUpdate) {
                chatbotWS.handleSystemUpdate({
                    type: 'system_update',
                    updateType: 'inventory',
                    message: `Added ${additionalStock} units to ${product.productName}. New stock level: ${product.stockQuantity}`
                });
            }
        }
    }
}

// Auto-refresh data every 30 seconds
setInterval(() => {
    updateLastUpdated();
    updateTemperatureDisplay();
}, 30000);

// Simulate temperature updates (for demo purposes)
setInterval(() => {
    temperatureData.forEach(temp => {
        // Simulate small temperature fluctuations
        const variation = (Math.random() - 0.5) * 0.5;
        temp.temperature += variation;
        temp.temperature = Math.round(temp.temperature * 10) / 10;
        
        // Update status based on temperature ranges
        if (temp.location === 'Cold Storage') {
            temp.status = (temp.temperature < 0 || temp.temperature > 8) ? 'Alert' : 'Normal';
        } else if (temp.location === 'Frozen Storage') {
            temp.status = (temp.temperature > -15) ? 'Alert' : 'Normal';
        } else if (temp.location === 'Dry Storage') {
            temp.status = (temp.temperature < 15 || temp.temperature > 25) ? 'Alert' : 'Normal';
        }
    });
    
    updateTemperatureDisplay();
    updateMetrics();
}, 60000); // Update every minute

// Handle responsive sidebar
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('active');
}

// Add mobile menu toggle (if needed)
if (window.innerWidth <= 768) {
    const mobileToggle = document.createElement('button');
    mobileToggle.innerHTML = '<i class="fas fa-bars"></i>';
    mobileToggle.className = 'btn btn-primary d-md-none';
    mobileToggle.style.cssText = 'position: fixed; top: 10px; left: 10px; z-index: 1001;';
    mobileToggle.addEventListener('click', toggleSidebar);
    document.body.appendChild(mobileToggle);
}

// Handle window resize
window.addEventListener('resize', () => {
    if (categoryChart) categoryChart.resize();
    if (spoilageChart) spoilageChart.resize();
});

// Export functions for global access
window.viewProduct = viewProduct;
window.addStock = addStock;
window.toggleChatbot = toggleChatbot;
window.closeChatbot = closeChatbot;
window.sendChatMessage = sendChatMessage;