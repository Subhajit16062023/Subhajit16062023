// WebSocket client for chatbot functionality
class ChatbotWebSocket {
    constructor() {
        this.socket = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 1000;
        this.isConnected = false;
        this.messageQueue = [];
        
        this.connect();
    }
    
    connect() {
        try {
            // Determine WebSocket URL based on current location
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const wsUrl = `${protocol}//${window.location.host}/ws`;
            
            this.socket = new WebSocket(wsUrl);
            
            this.socket.onopen = () => {
                console.log('WebSocket connected');
                this.isConnected = true;
                this.reconnectAttempts = 0;
                this.processMessageQueue();
            };
            
            this.socket.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    this.handleMessage(data);
                } catch (error) {
                    console.error('Error parsing WebSocket message:', error);
                }
            };
            
            this.socket.onclose = () => {
                console.log('WebSocket disconnected');
                this.isConnected = false;
                this.attemptReconnect();
            };
            
            this.socket.onerror = (error) => {
                console.error('WebSocket error:', error);
                this.isConnected = false;
            };
            
        } catch (error) {
            console.error('Error creating WebSocket connection:', error);
            this.attemptReconnect();
        }
    }
    
    attemptReconnect() {
        if (this.reconnectAttempts < this.maxReconnectAttempts) {
            this.reconnectAttempts++;
            console.log(`Attempting to reconnect (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
            
            setTimeout(() => {
                this.connect();
            }, this.reconnectDelay * this.reconnectAttempts);
        } else {
            console.error('Max reconnection attempts reached. Falling back to offline mode.');
            this.fallbackToOfflineMode();
        }
    }
    
    fallbackToOfflineMode() {
        // Use local chatbot responses when WebSocket is not available
        this.isConnected = false;
        console.log('Chatbot running in offline mode');
    }
    
    sendMessage(message) {
        if (this.isConnected && this.socket.readyState === WebSocket.OPEN) {
            this.socket.send(JSON.stringify({
                type: 'chat_message',
                message: message,
                timestamp: new Date().toISOString()
            }));
        } else {
            // Queue message or handle offline
            this.messageQueue.push(message);
            this.handleOfflineMessage(message);
        }
    }
    
    handleMessage(data) {
        if (data.type === 'chat_response') {
            this.displayBotMessage(data.message);
        } else if (data.type === 'system_update') {
            this.handleSystemUpdate(data);
        }
    }
    
    handleOfflineMessage(message) {
        // Generate offline response
        const response = this.generateOfflineResponse(message);
        setTimeout(() => {
            this.displayBotMessage(response);
        }, 1000);
    }
    
    generateOfflineResponse(message) {
        const responses = {
            inventory: "I can help you check current inventory levels. Based on your data, you have several products with varying stock levels. Would you like me to highlight items that need reordering?",
            expiration: "I can see several items with upcoming expiration dates. Your Bell Pepper expires on 1/31/2025, and you have multiple products that may need immediate attention. Would you like a detailed expiration report?",
            temperature: "Temperature monitoring shows your Cold Storage is at 4.2°C (Normal), Frozen Storage at -18.5°C (Normal), and Dry Storage at 22.1°C with an Alert status due to humidity levels.",
            waste: "Historical waste data shows that Fruits & Vegetables category has the highest risk products. I recommend reviewing expiration dates and adjusting order quantities for perishable items.",
            risk: "You currently have 9 high-risk items in your inventory. These include Bell Pepper, Vegetable Oil, Parmesan Cheese, and others. Would you like me to provide specific recommendations for each?",
            help: "I can assist with inventory management, expiration monitoring, temperature alerts, waste analysis, and product recommendations. What specific area would you like help with?",
            stock: "Current stock levels vary across products. Bell Pepper has 46 units (reorder level: 64), Vegetable Oil has 51 units (reorder level: 87). Several items are below reorder levels.",
            alerts: "Current alerts: 1 temperature alert in Dry Storage, 9 high-risk items for spoilage, and 3 products expiring within 30 days.",
            analytics: "Analytics show high turnover rates for Carrot (95%) and Coconut Sugar (89%). Lower turnover for Parmesan Cheese (24%). Consider adjusting orders based on these trends."
        };

        const messageWords = message.toLowerCase();
        for (const [key, response] of Object.entries(responses)) {
            if (messageWords.includes(key)) {
                return response;
            }
        }

        return "I can help you with inventory management, expiration monitoring, temperature alerts, and waste analysis. Please ask me about any of these topics, or type 'help' for more information!";
    }
    
    displayBotMessage(message) {
        const messagesContainer = document.getElementById('chatbotMessages');
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message bot-message';
        messageDiv.innerHTML = `
            <div class="message-content">${message}</div>
            <div class="message-time">${new Date().toLocaleTimeString()}</div>
        `;
        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    displayUserMessage(message) {
        const messagesContainer = document.getElementById('chatbotMessages');
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message user-message';
        messageDiv.innerHTML = `
            <div class="message-content">${message}</div>
            <div class="message-time">${new Date().toLocaleTimeString()}</div>
        `;
        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    processMessageQueue() {
        while (this.messageQueue.length > 0) {
            const message = this.messageQueue.shift();
            this.sendMessage(message);
        }
    }
    
    handleSystemUpdate(data) {
        // Handle system updates like inventory changes, temperature alerts, etc.
        console.log('System update received:', data);
        
        if (data.updateType === 'inventory') {
            this.displayBotMessage(`Inventory Update: ${data.message}`);
        } else if (data.updateType === 'temperature') {
            this.displayBotMessage(`Temperature Alert: ${data.message}`);
        } else if (data.updateType === 'expiration') {
            this.displayBotMessage(`Expiration Alert: ${data.message}`);
        }
    }
    
    close() {
        if (this.socket) {
            this.socket.close();
        }
    }
}

// Initialize WebSocket connection
let chatbotWS = null;

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Try to connect to WebSocket, fallback to offline mode if needed
    try {
        chatbotWS = new ChatbotWebSocket();
    } catch (error) {
        console.log('WebSocket not available, using offline mode');
        chatbotWS = {
            sendMessage: function(message) {
                // Simulate offline response
                setTimeout(() => {
                    const response = generateOfflineResponse(message);
                    displayBotMessage(response);
                }, 1000);
            },
            displayBotMessage: function(message) {
                const messagesContainer = document.getElementById('chatbotMessages');
                const messageDiv = document.createElement('div');
                messageDiv.className = 'message bot-message';
                messageDiv.innerHTML = `
                    <div class="message-content">${message}</div>
                    <div class="message-time">${new Date().toLocaleTimeString()}</div>
                `;
                messagesContainer.appendChild(messageDiv);
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            },
            displayUserMessage: function(message) {
                const messagesContainer = document.getElementById('chatbotMessages');
                const messageDiv = document.createElement('div');
                messageDiv.className = 'message user-message';
                messageDiv.innerHTML = `
                    <div class="message-content">${message}</div>
                    <div class="message-time">${new Date().toLocaleTimeString()}</div>
                `;
                messagesContainer.appendChild(messageDiv);
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            }
        };
    }
});

// Cleanup on page unload
window.addEventListener('beforeunload', function() {
    if (chatbotWS && chatbotWS.close) {
        chatbotWS.close();
    }
});

// Fallback offline response function
function generateOfflineResponse(message) {
    const responses = {
        inventory: "I can help you check current inventory levels. Based on your data, you have several products with varying stock levels. Would you like me to highlight items that need reordering?",
        expiration: "I can see several items with upcoming expiration dates. Your Bell Pepper expires on 1/31/2025, and you have multiple products that may need immediate attention. Would you like a detailed expiration report?",
        temperature: "Temperature monitoring shows your Cold Storage is at 4.2°C (Normal), Frozen Storage at -18.5°C (Normal), and Dry Storage at 22.1°C with an Alert status due to humidity levels.",
        waste: "Historical waste data shows that Fruits & Vegetables category has the highest risk products. I recommend reviewing expiration dates and adjusting order quantities for perishable items.",
        risk: "You currently have 9 high-risk items in your inventory. These include Bell Pepper, Vegetable Oil, Parmesan Cheese, and others. Would you like me to provide specific recommendations for each?",
        help: "I can assist with inventory management, expiration monitoring, temperature alerts, waste analysis, and product recommendations. What specific area would you like help with?"
    };

    const messageWords = message.toLowerCase();
    for (const [key, response] of Object.entries(responses)) {
        if (messageWords.includes(key)) {
            return response;
        }
    }

    return "I can help you with inventory management, expiration monitoring, temperature alerts, and waste analysis. Please ask me about any of these topics, or type 'help' for more information!";
}

function displayBotMessage(message) {
    const messagesContainer = document.getElementById('chatbotMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message bot-message';
    messageDiv.innerHTML = `
        <div class="message-content">${message}</div>
        <div class="message-time">${new Date().toLocaleTimeString()}</div>
    `;
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}