// Sample data for the retail dashboard
const sampleProducts = [
    {
        id: 1,
        productName: "Bell Pepper",
        category: "Fruits & Vegetables",
        supplierName: "Eimbee",
        warehouseLocation: "20 Pennsylvania Parkway",
        status: "Discontinued",
        productId: "29-017-6255",
        supplierId: "43-348-2450",
        dateReceived: "03-01-2024",
        lastOrderDate: "01-06-2025",
        expirationDate: "1/31/2025",
        stockQuantity: 46,
        reorderLevel: 64,
        reorderQuantity: 17,
        unitPrice: "$4.60",
        salesVolume: 96,
        inventoryTurnoverRate: 55,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: null
    },
    {
        id: 2,
        productName: "Vegetable Oil",
        category: "Oils & Fats",
        supplierName: "Digitube",
        warehouseLocation: "03643 Oakridge Lane",
        status: "Backordered",
        productId: "79-569-8856",
        supplierId: "04-854-7165",
        dateReceived: "04-01-2024",
        lastOrderDate: "5/19/2024",
        expirationDate: "06-11-2024",
        stockQuantity: 51,
        reorderLevel: 87,
        reorderQuantity: 86,
        unitPrice: "$2.00",
        salesVolume: 24,
        inventoryTurnoverRate: 83,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: 10
    },
    {
        id: 3,
        productName: "Parmesan Cheese",
        category: "Dairy",
        supplierName: "BlogXS",
        warehouseLocation: "73 Graedel Street",
        status: "Discontinued",
        productId: "28-146-2641",
        supplierId: "82-995-0739",
        dateReceived: "04-01-2024",
        lastOrderDate: "12/21/2024",
        expirationDate: "04-08-2024",
        stockQuantity: 38,
        reorderLevel: 67,
        reorderQuantity: 66,
        unitPrice: "$12.00",
        salesVolume: 35,
        inventoryTurnoverRate: 24,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: null
    },
    {
        id: 4,
        productName: "Carrot",
        category: "Fruits & Vegetables",
        supplierName: "Avaveo",
        warehouseLocation: "44801 Myrtle Center",
        status: "Discontinued",
        productId: "11-581-9869",
        supplierId: "22-867-3079",
        dateReceived: "05-01-2024",
        lastOrderDate: "12-12-2024",
        expirationDate: "9/26/2024",
        stockQuantity: 51,
        reorderLevel: 60,
        reorderQuantity: 98,
        unitPrice: "$1.50",
        salesVolume: 44,
        inventoryTurnoverRate: 95,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: null
    },
    {
        id: 5,
        productName: "Garlic",
        category: "Fruits & Vegetables",
        supplierName: "Katz",
        warehouseLocation: "6195 Monterey Center",
        status: "Discontinued",
        productId: "13-202-4809",
        supplierId: "24-281-7685",
        dateReceived: "05-01-2024",
        lastOrderDate: "7/28/2024",
        expirationDate: "5/20/2024",
        stockQuantity: 27,
        reorderLevel: 22,
        reorderQuantity: 89,
        unitPrice: "$7.00",
        salesVolume: 91,
        inventoryTurnoverRate: 77,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: null
    },
    {
        id: 6,
        productName: "Lemon",
        category: "Fruits & Vegetables",
        supplierName: "Yata",
        warehouseLocation: "5141 Anniversary Crossing",
        status: "Backordered",
        productId: "70-145-2550",
        supplierId: "75-849-4524",
        dateReceived: "05-01-2024",
        lastOrderDate: "08-07-2024",
        expirationDate: "08-06-2024",
        stockQuantity: 91,
        reorderLevel: 6,
        reorderQuantity: 37,
        unitPrice: "$2.40",
        salesVolume: 38,
        inventoryTurnoverRate: 70,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: 10
    },
    {
        id: 7,
        productName: "Coconut Sugar",
        category: "Grains & Pulses",
        supplierName: "Lazz",
        warehouseLocation: "38583 2nd Pass",
        status: "Active",
        productId: "10-626-8536",
        supplierId: "23-274-3305",
        dateReceived: "05-01-2024",
        lastOrderDate: "1/29/2025",
        expirationDate: "3/30/2024",
        stockQuantity: 17,
        reorderLevel: 85,
        reorderQuantity: 74,
        unitPrice: "$5.00",
        salesVolume: 76,
        inventoryTurnoverRate: 89,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: 20
    },
    {
        id: 8,
        productName: "Anchovies",
        category: "Seafood",
        supplierName: "Zoonder",
        warehouseLocation: "86 Porter Junction",
        status: "Discontinued",
        productId: "42-879-9478",
        supplierId: "00-900-0119",
        dateReceived: "06-01-2024",
        lastOrderDate: "2/23/2025",
        expirationDate: "8/22/2024",
        stockQuantity: 81,
        reorderLevel: 22,
        reorderQuantity: 20,
        unitPrice: "$10.00",
        salesVolume: 95,
        inventoryTurnoverRate: 77,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: null
    },
    {
        id: 9,
        productName: "Cheese",
        category: "Dairy",
        supplierName: "Oozz",
        warehouseLocation: "05518 Saint Paul Street",
        status: "Active",
        productId: "82-380-5378",
        supplierId: "96-353-3049",
        dateReceived: "06-01-2024",
        lastOrderDate: "06-03-2024",
        expirationDate: "03-07-2024",
        stockQuantity: 78,
        reorderLevel: 24,
        reorderQuantity: 31,
        unitPrice: "$9.00",
        salesVolume: 60,
        inventoryTurnoverRate: 41,
        spoilageRisk: "High",
        shelfLifeDecayPercentage: 20
    }
];

const temperatureData = [
    {
        location: "Cold Storage",
        temperature: 4.2,
        humidity: 65,
        status: "Normal"
    },
    {
        location: "Frozen Storage",
        temperature: -18.5,
        humidity: 45,
        status: "Normal"
    },
    {
        location: "Dry Storage",
        temperature: 22.1,
        humidity: 55,
        status: "Alert"
    }
];

const spoilageTrendData = [
    { month: 'Jan', highRisk: 12, mediumRisk: 7, lowRisk: 15 },
    { month: 'Feb', highRisk: 19, mediumRisk: 11, lowRisk: 22 },
    { month: 'Mar', highRisk: 3, mediumRisk: 8, lowRisk: 18 },
    { month: 'Apr', highRisk: 5, mediumRisk: 12, lowRisk: 25 },
    { month: 'May', highRisk: 2, mediumRisk: 15, lowRisk: 30 },
    { month: 'Jun', highRisk: 9, mediumRisk: 6, lowRisk: 28 }
];

// Utility functions
function calculateDaysUntilExpiration(expirationDate) {
    const expDate = new Date(expirationDate);
    const today = new Date();
    const diffTime = expDate.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

function formatPrice(price) {
    if (typeof price === 'string' && price.startsWith('$')) {
        return price;
    }
    return `$${parseFloat(price).toFixed(2)}`;
}

function getExpirationStatus(expirationDate) {
    const days = calculateDaysUntilExpiration(expirationDate);
    if (days <= 7) return 'critical';
    if (days <= 30) return 'warning';
    return 'normal';
}

function getStatusBadgeClass(status) {
    const classes = {
        'Active': 'badge-active',
        'Discontinued': 'badge-discontinued',
        'Backordered': 'badge-backordered'
    };
    return classes[status] || 'badge-active';
}

function getRiskBadgeClass(risk) {
    const classes = {
        'High': 'badge-high-risk',
        'Medium': 'badge-medium-risk',
        'Low': 'badge-low-risk'
    };
    return classes[risk] || 'badge-high-risk';
}

function getExpirationWarning(expirationDate) {
    const days = calculateDaysUntilExpiration(expirationDate);
    if (days <= 7) {
        return `<div class="expiration-warning">
            <i class="fas fa-exclamation-triangle"></i>
            Expires in ${days} days
        </div>`;
    } else if (days <= 30) {
        return `<div class="expiration-warning expiration-soon">
            <i class="fas fa-clock"></i>
            Expires in ${days} days
        </div>`;
    }
    return '';
}

// Filter functions
function filterProducts(products, categoryFilter, statusFilter, riskFilter) {
    return products.filter(product => {
        const categoryMatch = !categoryFilter || product.category === categoryFilter;
        const statusMatch = !statusFilter || product.status === statusFilter;
        const riskMatch = !riskFilter || product.spoilageRisk === riskFilter;
        return categoryMatch && statusMatch && riskMatch;
    });
}

function getUniqueCategories(products) {
    return [...new Set(products.map(p => p.category))];
}

function getUniqueStatuses(products) {
    return [...new Set(products.map(p => p.status))];
}

function getUniqueRisks(products) {
    return [...new Set(products.map(p => p.spoilageRisk))];
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        sampleProducts,
        temperatureData,
        spoilageTrendData,
        calculateDaysUntilExpiration,
        formatPrice,
        getExpirationStatus,
        getStatusBadgeClass,
        getRiskBadgeClass,
        getExpirationWarning,
        filterProducts,
        getUniqueCategories,
        getUniqueStatuses,
        getUniqueRisks
    };
}